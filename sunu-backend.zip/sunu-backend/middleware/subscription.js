const db = require("../db");

// Bloque l'accès aux routes métier si l'abonnement de l'entreprise n'est
// plus actif. Les routes d'authentification et de facturation restent
// toujours accessibles (pour permettre de payer et de se reconnecter).
function requireActiveSubscription(req, res, next) {
  const company = db.prepare("SELECT subscription_status, subscription_expiry FROM companies WHERE id = ?")
    .get(req.user.companyId);

  if (!company) return res.status(404).json({ error: "Entreprise introuvable." });

  const expired = company.subscription_expiry && new Date(company.subscription_expiry) < new Date();
  const blocked = expired || company.subscription_status === "cancelled" || company.subscription_status === "past_due";

  if (blocked) {
    return res.status(402).json({
      error: "Abonnement inactif ou expiré.",
      subscriptionStatus: company.subscription_status,
      subscriptionExpiry: company.subscription_expiry
    });
  }
  next();
}

module.exports = { requireActiveSubscription };
