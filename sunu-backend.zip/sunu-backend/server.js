require("dotenv").config();
const express = require("express");
const cors = require("cors");

const { requireAuth } = require("./middleware/auth");
const { requireActiveSubscription } = require("./middleware/subscription");

const authRoutes = require("./routes/auth");
const clientsRoutes = require("./routes/clients");
const productsRoutes = require("./routes/products");
const ordersRoutes = require("./routes/orders");
const invoicesRoutes = require("./routes/invoices");
const billingRoutes = require("./routes/billing");

const app = express();
app.use(cors());
app.use(express.json());

// Routes publiques (pas besoin d'être connecté)
app.use("/api/auth", authRoutes);

// Le webhook de paiement doit rester accessible SANS JWT : il est appelé
// par le fournisseur de paiement, pas par un navigateur connecté. Il est
// donc monté ici, avant le middleware requireAuth ci-dessous.
app.post("/api/billing/webhook", express.json(), (req, res, next) => {
  billingRoutes.handle(req, res, next);
});

// Tout ce qui suit nécessite d'être connecté (JWT valide)
app.use("/api", requireAuth);
app.use("/api/billing", billingRoutes); // /subscribe (le /webhook déjà monté plus haut est ignoré ici)

// Tout ce qui suit nécessite en plus un abonnement actif
app.use("/api/clients", requireActiveSubscription, clientsRoutes);
app.use("/api/products", requireActiveSubscription, productsRoutes);
app.use("/api/orders", requireActiveSubscription, ordersRoutes);
app.use("/api/invoices", requireActiveSubscription, invoicesRoutes);

app.get("/api/health", (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Sunu Gestion API démarrée sur le port ${PORT}`));
