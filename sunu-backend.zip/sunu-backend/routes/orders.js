const express = require("express");
const { v4: uuid } = require("uuid");
const db = require("../db");
const router = express.Router();

function nextNumber(company, kind) {
  const prefix = kind === "order" ? company.order_prefix : company.invoice_prefix;
  const counter = kind === "order" ? company.order_counter : company.invoice_counter;
  const year = new Date().getFullYear();
  const number = `${prefix}-${year}-${String(counter).padStart(4, "0")}`;
  const column = kind === "order" ? "order_counter" : "invoice_counter";
  db.prepare(`UPDATE companies SET ${column} = ${column} + 1 WHERE id = ?`).run(company.id);
  return number;
}

router.get("/", (req, res) => {
  const rows = db.prepare("SELECT * FROM orders WHERE company_id = ? ORDER BY created_at DESC")
    .all(req.user.companyId);
  res.json(rows.map(r => ({ ...r, items: JSON.parse(r.items_json) })));
});

router.post("/", (req, res) => {
  const { clientId, date, items } = req.body;
  if (!clientId || !Array.isArray(items) || !items.length) {
    return res.status(400).json({ error: "clientId et items (non vide) sont requis." });
  }
  const company = db.prepare("SELECT * FROM companies WHERE id = ?").get(req.user.companyId);
  const id = uuid();
  const number = nextNumber(company, "order");
  db.prepare(`INSERT INTO orders (id, company_id, number, client_id, date, items_json)
              VALUES (?, ?, ?, ?, ?, ?)`)
    .run(id, req.user.companyId, number, clientId, date, JSON.stringify(items));
  res.status(201).json({ id, number, clientId, date, items, status: "en cours" });
});

router.patch("/:id/status", (req, res) => {
  const { status } = req.body;
  if (!["en cours", "livrée", "annulée"].includes(status)) {
    return res.status(400).json({ error: "Statut invalide." });
  }
  db.prepare("UPDATE orders SET status = ? WHERE id = ? AND company_id = ?")
    .run(status, req.params.id, req.user.companyId);
  res.json({ id: req.params.id, status });
});

router.delete("/:id", (req, res) => {
  db.prepare("DELETE FROM orders WHERE id = ? AND company_id = ?")
    .run(req.params.id, req.user.companyId);
  res.status(204).end();
});

module.exports = router;
