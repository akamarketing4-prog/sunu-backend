const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { v4: uuid } = require("uuid");
const db = require("../db");

const router = express.Router();

// Durée d'essai gratuite à l'inscription
const TRIAL_DAYS = 14;

router.post("/signup", (req, res) => {
  const { companyName, email, password } = req.body;
  if (!companyName || !email || !password) {
    return res.status(400).json({ error: "companyName, email et password sont requis." });
  }
  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (existing) return res.status(409).json({ error: "Cet email est déjà utilisé." });

  const companyId = uuid();
  const trialExpiry = new Date(Date.now() + TRIAL_DAYS * 86400000).toISOString().slice(0, 10);

  db.prepare(`INSERT INTO companies (id, name, subscription_status, subscription_expiry)
              VALUES (?, ?, 'trialing', ?)`).run(companyId, companyName, trialExpiry);

  const userId = uuid();
  const passwordHash = bcrypt.hashSync(password, 10);
  db.prepare(`INSERT INTO users (id, company_id, email, password_hash, role)
              VALUES (?, ?, ?, ?, 'owner')`).run(userId, companyId, email, passwordHash);

  const token = signToken({ userId, companyId, role: "owner" });
  res.status(201).json({ token, trialExpiry });
});

router.post("/login", (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user || !bcrypt.compareSync(password || "", user.password_hash)) {
    return res.status(401).json({ error: "Email ou mot de passe incorrect." });
  }
  const token = signToken({ userId: user.id, companyId: user.company_id, role: user.role });
  res.json({ token });
});

function signToken(payload) {
  return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: "30d" });
}

module.exports = router;
