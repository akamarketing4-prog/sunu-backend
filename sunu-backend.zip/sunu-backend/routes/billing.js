const express = require("express");
const { v4: uuid } = require("uuid");
const db = require("../db");
const router = express.Router();

const PLAN_PRICES = { monthly: 7500, semi: 40000, yearly: 72000 };
const PLAN_MONTHS = { monthly: 1, semi: 6, yearly: 12 };

// Démarre un paiement d'abonnement. À COMPLÉTER : appelez ici l'API de
// votre agrégateur (CinetPay ou PayDunya) pour créer une session de
// paiement, puis renvoyez son URL de paiement au client pour redirection.
router.post("/subscribe", (req, res) => {
  const { plan } = req.body;
  if (!PLAN_PRICES[plan]) return res.status(400).json({ error: "Formule invalide." });

  const paymentId = uuid();
  const amount = PLAN_PRICES[plan];

  db.prepare(`INSERT INTO subscription_payments (id, company_id, plan, amount, status)
              VALUES (?, ?, ?, ?, 'pending')`)
    .run(paymentId, req.user.companyId, plan, amount);

  // --- Exemple d'intégration CinetPay (à adapter avec vos identifiants) ---
  // const response = await fetch("https://api-checkout.cinetpay.com/v2/payment", {
  //   method: "POST",
  //   headers: { "Content-Type": "application/json" },
  //   body: JSON.stringify({
  //     apikey: process.env.PAYMENT_API_KEY,
  //     site_id: process.env.PAYMENT_SITE_ID,
  //     transaction_id: paymentId,
  //     amount,
  //     currency: "XOF",
  //     notify_url: `${process.env.PUBLIC_BASE_URL}/api/billing/webhook`,
  //     return_url: `${process.env.PUBLIC_BASE_URL}/abonnement/confirmation`,
  //     channels: "ALL" // Wave, Orange Money, carte...
  //   })
  // });
  // const data = await response.json();
  // return res.json({ paymentId, paymentUrl: data.data.payment_url });

  res.json({
    paymentId,
    amount,
    note: "Intégration du fournisseur de paiement non branchée — voir le commentaire dans ce fichier."
  });
});

// Webhook appelé par le fournisseur de paiement quand une transaction est
// confirmée. Vérifiez TOUJOURS la signature/le secret avant de faire
// confiance à cet appel (voir PAYMENT_WEBHOOK_SECRET dans .env).
router.post("/webhook", express.json(), (req, res) => {
  const { transaction_id, status } = req.body; // forme exacte à adapter au fournisseur choisi

  const payment = db.prepare("SELECT * FROM subscription_payments WHERE id = ?").get(transaction_id);
  if (!payment) return res.status(404).json({ error: "Paiement introuvable." });

  if (status === "ACCEPTED" || status === "success" || status === "completed") {
    db.prepare("UPDATE subscription_payments SET status = 'confirmed' WHERE id = ?").run(payment.id);

    const company = db.prepare("SELECT * FROM companies WHERE id = ?").get(payment.company_id);
    const base = company.subscription_expiry && new Date(company.subscription_expiry) > new Date()
      ? new Date(company.subscription_expiry) // prolonge un abonnement encore actif
      : new Date();
    base.setMonth(base.getMonth() + PLAN_MONTHS[payment.plan]);

    db.prepare(`UPDATE companies SET plan = ?, subscription_status = 'active', subscription_expiry = ?
                WHERE id = ?`)
      .run(payment.plan, base.toISOString().slice(0, 10), company.id);
  } else {
    db.prepare("UPDATE subscription_payments SET status = 'failed' WHERE id = ?").run(payment.id);
  }

  res.status(200).json({ received: true });
});

module.exports = router;
