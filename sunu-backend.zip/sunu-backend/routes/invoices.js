const express = require("express");
const { v4: uuid } = require("uuid");
const db = require("../db");
const router = express.Router();

function totals(items, vatRate) {
  const ht = items.reduce((s, l) => s + l.qty * l.unitPrice, 0);
  const vat = ht * vatRate / 100;
  return { ht, vat, ttc: ht + vat };
}

router.get("/", (req, res) => {
  const rows = db.prepare("SELECT * FROM invoices WHERE company_id = ? ORDER BY created_at DESC")
    .all(req.user.companyId);
  res.json(rows.map(r => {
    const items = JSON.parse(r.items_json);
    return { ...r, items, ...totals(items, r.vat_rate) };
  }));
});

router.post("/", (req, res) => {
  const { clientId, orderId, date, items, vatRate } = req.body;
  if (!clientId || !Array.isArray(items) || !items.length) {
    return res.status(400).json({ error: "clientId et items (non vide) sont requis." });
  }
  const company = db.prepare("SELECT * FROM companies WHERE id = ?").get(req.user.companyId);
  const number = `${company.invoice_prefix}-${new Date().getFullYear()}-${String(company.invoice_counter).padStart(4, "0")}`;
  db.prepare("UPDATE companies SET invoice_counter = invoice_counter + 1 WHERE id = ?").run(company.id);

  const id = uuid();
  const rate = vatRate != null ? vatRate : company.vat_rate;
  db.prepare(`INSERT INTO invoices (id, company_id, number, client_id, order_id, date, vat_rate, items_json)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(id, req.user.companyId, number, clientId, orderId || null, date, rate, JSON.stringify(items));

  // Décrémente le stock des articles de type "produit"
  const getProduct = db.prepare("SELECT * FROM products WHERE id = ? AND company_id = ?");
  const updateStock = db.prepare("UPDATE products SET stock = ? WHERE id = ?");
  for (const line of items) {
    const product = getProduct.get(line.productId, req.user.companyId);
    if (product && product.type === "produit" && product.stock != null) {
      updateStock.run(Math.max(0, product.stock - line.qty), product.id);
    }
  }

  res.status(201).json({ id, number, clientId, orderId, date, vatRate: rate, items, status: "brouillon", ...totals(items, rate) });
});

router.patch("/:id/status", (req, res) => {
  const { status } = req.body;
  if (!["brouillon", "envoyée", "payée"].includes(status)) {
    return res.status(400).json({ error: "Statut invalide." });
  }
  db.prepare("UPDATE invoices SET status = ? WHERE id = ? AND company_id = ?")
    .run(status, req.params.id, req.user.companyId);
  res.json({ id: req.params.id, status });
});

router.delete("/:id", (req, res) => {
  db.prepare("DELETE FROM invoices WHERE id = ? AND company_id = ?")
    .run(req.params.id, req.user.companyId);
  res.status(204).end();
});

module.exports = router;
