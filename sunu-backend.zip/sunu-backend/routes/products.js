const express = require("express");
const { v4: uuid } = require("uuid");
const db = require("../db");
const router = express.Router();

router.get("/", (req, res) => {
  const rows = db.prepare("SELECT * FROM products WHERE company_id = ? ORDER BY created_at DESC")
    .all(req.user.companyId);
  res.json(rows);
});

router.post("/", (req, res) => {
  const { name, type, price, stock, threshold } = req.body;
  if (!name || !type || price == null) {
    return res.status(400).json({ error: "name, type et price sont requis." });
  }
  const id = uuid();
  db.prepare(`INSERT INTO products (id, company_id, name, type, price, stock, threshold)
              VALUES (?, ?, ?, ?, ?, ?, ?)`)
    .run(id, req.user.companyId, name, type, price, type === "produit" ? (stock || 0) : null,
         type === "produit" ? (threshold || 0) : null);
  res.status(201).json({ id, name, type, price, stock, threshold });
});

router.patch("/:id/stock", (req, res) => {
  const { delta } = req.body; // e.g. -2 to decrement by 2
  const product = db.prepare("SELECT * FROM products WHERE id = ? AND company_id = ?")
    .get(req.params.id, req.user.companyId);
  if (!product) return res.status(404).json({ error: "Article introuvable." });
  const newStock = Math.max(0, (product.stock || 0) + delta);
  db.prepare("UPDATE products SET stock = ? WHERE id = ?").run(newStock, product.id);
  res.json({ id: product.id, stock: newStock });
});

router.delete("/:id", (req, res) => {
  db.prepare("DELETE FROM products WHERE id = ? AND company_id = ?")
    .run(req.params.id, req.user.companyId);
  res.status(204).end();
});

module.exports = router;
