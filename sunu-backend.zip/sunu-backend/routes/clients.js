const express = require("express");
const { v4: uuid } = require("uuid");
const db = require("../db");
const router = express.Router();

router.get("/", (req, res) => {
  const rows = db.prepare("SELECT * FROM clients WHERE company_id = ? ORDER BY created_at DESC")
    .all(req.user.companyId);
  res.json(rows);
});

router.post("/", (req, res) => {
  const { name, phone, email, address } = req.body;
  if (!name) return res.status(400).json({ error: "name est requis." });
  const id = uuid();
  db.prepare(`INSERT INTO clients (id, company_id, name, phone, email, address)
              VALUES (?, ?, ?, ?, ?, ?)`)
    .run(id, req.user.companyId, name, phone || "", email || "", address || "");
  res.status(201).json({ id, name, phone, email, address });
});

router.delete("/:id", (req, res) => {
  db.prepare("DELETE FROM clients WHERE id = ? AND company_id = ?")
    .run(req.params.id, req.user.companyId);
  res.status(204).end();
});

module.exports = router;
