// Base de données SQLite locale (fichier data.db à côté de ce script).
// Pour un usage en production avec plusieurs serveurs, remplacez par
// PostgreSQL — la structure des tables reste identique.

const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(path.join(__dirname, "data.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS companies (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  ninea TEXT,
  phone TEXT,
  email TEXT,
  address TEXT,
  vat_rate REAL DEFAULT 18,
  invoice_prefix TEXT DEFAULT 'FAC',
  order_prefix TEXT DEFAULT 'CMD',
  invoice_counter INTEGER DEFAULT 1,
  order_counter INTEGER DEFAULT 1,
  plan TEXT DEFAULT 'monthly',       -- monthly | semi | yearly
  subscription_status TEXT DEFAULT 'trialing', -- trialing | active | past_due | cancelled
  subscription_expiry TEXT,          -- ISO date
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT DEFAULT 'owner',         -- owner | staff
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS clients (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  address TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  type TEXT NOT NULL,                -- produit | service
  price REAL NOT NULL,
  stock INTEGER,
  threshold INTEGER,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  number TEXT NOT NULL,
  client_id TEXT REFERENCES clients(id),
  date TEXT NOT NULL,
  status TEXT DEFAULT 'en cours',    -- en cours | livrée | annulée
  items_json TEXT NOT NULL,          -- [{productId, name, qty, unitPrice}]
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS invoices (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  number TEXT NOT NULL,
  client_id TEXT REFERENCES clients(id),
  order_id TEXT REFERENCES orders(id),
  date TEXT NOT NULL,
  vat_rate REAL NOT NULL,
  status TEXT DEFAULT 'brouillon',   -- brouillon | envoyée | payée
  items_json TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS subscription_payments (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  plan TEXT NOT NULL,
  amount REAL NOT NULL,
  provider_reference TEXT,
  status TEXT DEFAULT 'pending',     -- pending | confirmed | failed
  created_at TEXT DEFAULT (datetime('now'))
);
`);

module.exports = db;
