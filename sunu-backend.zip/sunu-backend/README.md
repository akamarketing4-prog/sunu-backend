# Sunu Gestion — API backend

Backend réel (multi-entreprise) pour l'application de gestion commerciale :
comptes, abonnements, clients, catalogue, commandes, factures.

Ce code n'a pas pu être testé dans l'environnement où il a été généré
(pas d'accès réseau). Avant de l'utiliser en production, faites-le tourner
en local et testez chaque route.

## Installation locale

```bash
npm install
cp .env.example .env
# Ouvrez .env et remplissez au moins JWT_SECRET
npm run dev
```

L'API démarre sur `http://localhost:3000`. Une base SQLite (`data.db`) est
créée automatiquement au premier lancement.

## Aperçu des routes

| Méthode | Route | Auth requise | Description |
|---|---|---|---|
| POST | `/api/auth/signup` | non | Crée une entreprise + un compte, démarre l'essai gratuit de 14 jours |
| POST | `/api/auth/login` | non | Connexion, renvoie un token JWT |
| GET/POST | `/api/clients` | oui + abonnement actif | Liste / création de clients |
| GET/POST | `/api/products` | oui + abonnement actif | Catalogue produits et services |
| GET/POST | `/api/orders` | oui + abonnement actif | Commandes |
| GET/POST | `/api/invoices` | oui + abonnement actif | Factures (calcule HT/TVA/TTC, décrémente le stock) |
| POST | `/api/billing/subscribe` | oui | Démarre un paiement d'abonnement |
| POST | `/api/billing/webhook` | non (appelé par le fournisseur) | Confirme un paiement et active l'abonnement |

Toutes les routes protégées attendent l'en-tête :
`Authorization: Bearer <token reçu au login>`

## Ce qu'il reste à faire avant une mise en production

1. **Brancher un vrai fournisseur de paiement** (CinetPay ou PayDunya
   recommandés au Sénégal — ils gèrent Wave, Orange Money et carte en une
   seule intégration). Le code d'exemple est commenté dans
   `routes/billing.js` : créez un compte marchand, récupérez vos clés API,
   et adaptez l'appel.
2. **Vérifier la signature du webhook** avec `PAYMENT_WEBHOOK_SECRET` avant
   de faire confiance à un appel entrant — sinon n'importe qui pourrait
   simuler un paiement réussi.
3. **Remplacer SQLite par PostgreSQL** si vous prévoyez plusieurs serveurs
   ou une forte charge (SQLite convient très bien pour démarrer).
4. **Déployer** sur un hébergeur comme Railway, Render ou Fly.io (tous ont
   une offre gratuite ou très abordable pour démarrer).
5. **Adapter l'application front-end** (le fichier `gestion-commerciale.html`
   déjà construit) pour qu'elle appelle cette API au lieu de `localStorage` —
   chaque fonction de sauvegarde locale devient un appel `fetch()` vers les
   routes ci-dessus.
6. **Retirer le système de code d'activation actuel** dans le front-end : il
   devient inutile une fois que `requireActiveSubscription` fait ce travail
   côté serveur, de façon réellement sécurisée.

## Prochaine étape recommandée

Ouvrez ce dossier dans **Claude Code** pour : installer les dépendances,
corriger les éventuelles erreurs au premier lancement, brancher le
fournisseur de paiement avec vos vraies clés, connecter le front-end à
cette API, et déployer le tout.
